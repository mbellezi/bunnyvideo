<?php
defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/completionlib.php');
// Garante que a classe de evento seja carregada pelo autoloader
// require_once($CFG->dirroot . '/mod/bunnyvideo/classes/event/course_module_viewed.php'); // Não é mais necessário aqui

/**
 * @param stdClass $bunnyvideo Uma instância de bunnyvideo do banco de dados
 * @param stdClass $cm A instância do módulo do curso à qual pertence
 * @param context_module $context O contexto da instância do módulo
 * @param array $options Outras opções de exibição
 * @return string Saída HTML para a página da atividade.
 */
function bunnyvideo_view($bunnyvideo, $cm, $context, $options = null)
{
    global $CFG, $PAGE, $OUTPUT, $USER, $DB; // Adicionado global $DB

    // Obtém os dados do curso - necessários para snapshots de registro
    $course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);

    try {
        // Dispara o evento course_module_viewed. Log padrão do Moodle.
        $event = \mod_bunnyvideo\event\course_module_viewed::create(array(
            'objectid' => $bunnyvideo->id,
            'context' => $context,
            'other' => array('userid' => $USER->id)
        ));

        // Adiciona snapshots de registro com tratamento de erros
        try {
            $event->add_record_snapshot('course', $course);
            $event->add_record_snapshot('course_modules', $cm);
            $event->add_record_snapshot('bunnyvideo', $bunnyvideo);
            $event->trigger();
        } catch (Exception $e) {
            // Registra o erro mas continua - não permite que a falha do evento impeça a visualização
            debugging('Erro no registro do evento: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    } catch (Exception $e) {
        // Apenas registra o erro mas continua carregando a página
        debugging('Erro ao criar evento: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }

    // Obtém o status de conclusão atual para o usuário
    $completion = new completion_info($course);
    $completiondata = $completion->get_data($cm, false, $USER->id);
    $completionstate = $completiondata->completionstate;
    $completionpercent = $bunnyvideo->completionpercent;

    // Determinar mensagem de status apropriada
    $statusmessage = '';
    if ($completionstate == COMPLETION_COMPLETE || $completionstate == COMPLETION_COMPLETE_PASS) {
        $statusmessage = '<div class="alert alert-success">' . get_string('completion_status_complete', 'mod_bunnyvideo') . '</div>';
    } else if ($completionpercent > 0) {
        $statusmessage = '<div class="alert alert-info">' .
            get_string('completion_status_incomplete', 'mod_bunnyvideo', $completionpercent) .
            '</div>';
    }

    // Verifica se o usuário atual pode gerenciar a conclusão (professor/admin)
    $canmanagecompletion = has_capability('mod/bunnyvideo:managecompletion', $context);

    $progressrecord = $DB->get_record('bunnyvideo_progress', [
        'bunnyvideoid' => $bunnyvideo->id,
        'userid' => $USER->id,
    ], 'lastposition, timewatched');
    $lastposition = $progressrecord ? (int) $progressrecord->lastposition : 0;
    $timewatched = $progressrecord ? (int) $progressrecord->timewatched : 0;

    // Adiciona botão de alternância para professores/admins
    if ($canmanagecompletion && $cm->completion != COMPLETION_TRACKING_NONE) {
        // Cria botão com ação oposta ao estado atual
        $buttonlabel = ($completionstate == COMPLETION_COMPLETE || $completionstate == COMPLETION_COMPLETE_PASS)
            ? get_string('mark_incomplete', 'mod_bunnyvideo')
            : get_string('mark_complete', 'mod_bunnyvideo');

        $newstate = ($completionstate == COMPLETION_COMPLETE || $completionstate == COMPLETION_COMPLETE_PASS)
            ? COMPLETION_INCOMPLETE
            : COMPLETION_COMPLETE;

        // Adiciona botão para alternar o status de conclusão
        $togglebutton = '<div class="completion-toggle-container float-right" style="margin-top: -40px; position: relative;">';
        $togglebutton .= '<button type="button" class="btn btn-sm ' .
            (($completionstate == COMPLETION_COMPLETE || $completionstate == COMPLETION_COMPLETE_PASS) ? 'btn-warning' : 'btn-success') .
            ' completion-toggle-button" data-cmid="' . $cm->id . '" data-userid="' . $USER->id . '" data-newstate="' . $newstate . '">';
        $togglebutton .= $buttonlabel . '</button>';
        $togglebutton .= '</div>';

        // Adiciona o botão de alternância à mensagem de status
        if (!empty($statusmessage)) {
            // Insere o botão na mensagem de status existente
            $statusmessage = str_replace('</div>', $togglebutton . '</div>', $statusmessage);
        } else {
            // Cria um novo container de status se não houver um
            $statusmessage = '<div class="alert alert-info">' . $togglebutton . '</div>';
        }
    }

    // Prepara dados para o JavaScript
    $jsdata = [
        'cmid' => $cm->id,
        'bunnyvideoid' => $bunnyvideo->id,
        'completionPercent' => $bunnyvideo->completionpercent > 0 ? (int) $bunnyvideo->completionpercent : 0,
        'contextid' => $context->id,
        'lastPosition' => $lastposition,
        'timeWatched' => $timewatched,
    ];

    // --- Geração do HTML usando $OUTPUT (Renderer Padrão) ---
    $html = '';

    // Incorpora o script Player.js diretamente na saída HTML
    $html .= '<script src="https://assets.mediadelivery.net/playerjs/player-0.1.0.min.js"></script>';

    // Então adiciona nosso script manipulador - isso garante a ordem correta
    $html .= '<script src="' . $CFG->wwwroot . '/mod/bunnyvideo/js/player_handler.js?v=' . time() . '"></script>';

    // Adiciona o script de alternância de conclusão se o usuário puder gerenciar a conclusão
    if ($canmanagecompletion && $cm->completion != COMPLETION_TRACKING_NONE) {
        $html .= '<script src="' . $CFG->wwwroot . '/mod/bunnyvideo/js/completion_toggle.js?v=' . time() . '"></script>';
    }

    // Inicializa somente depois que tudo estiver carregado
    $html .= '<script>
        document.addEventListener("DOMContentLoaded", function() {
            // Garante que tudo esteja disponível
            if (typeof BunnyVideoHandler !== "undefined") {
                console.log("BunnyVideo: Initializing handler after DOM loaded");
                BunnyVideoHandler.init(' . json_encode($jsdata) . ');
            } else {
                console.error("BunnyVideo: Handler not found even after direct embedding");
            }
        });
    </script>';

    // Formata o nome e a introdução
    $name = format_string($bunnyvideo->name, true, ['context' => $context]);
    $intro = format_module_intro('bunnyvideo', $bunnyvideo, $cm->id);

    // Verifica se o usuário tem capacidade de visualizar conteúdo confiável
    if (has_capability('moodle/site:trustcontent', $context)) {
        // Para professores e administradores, usa format_text normalmente
        $embedcode_html = format_text($bunnyvideo->embedcode, FORMAT_HTML, ['trusted' => true, 'noclean' => true, 'context' => $context]);
    } else {
        // Para estudantes, usa diretamente o código embed sem filtrar
        // Isso ignora os filtros de segurança, mas é necessário para mostrar o iframe
        $embedcode_html = $bunnyvideo->embedcode;
        debugging('BunnyVideo: Bypass Moodle format_text filtros para estudantes', DEBUG_DEVELOPER);
    }

    // Monta o conteúdo HTML usando $OUTPUT e html_writer
    $content = '';
    $content .= $OUTPUT->box_start('generalbox boxaligncenter mod_bunnyvideo_content', 'bunnyvideocontent-' . $bunnyvideo->id); // ID único para o container geral

    // Adiciona a mensagem de status de conclusão ANTES do conteúdo
    $content .= $statusmessage;

    // if (trim(strip_tags($intro))) {
    //      $content .= $OUTPUT->box($intro, 'mod_introbox'); // Caixa para a introdução
    // }

    // Adiciona um wrapper DIV com ID único para o JS encontrar o iframe facilmente
    $content .= '<div id="bunnyvideo-player-' . $bunnyvideo->id . '" class="bunnyvideo-player-wrapper">';
    $content .= $html; // Adiciona nossos scripts antes do código de incorporação
    $content .= $embedcode_html;
    $content .= '</div>';

    $content .= $OUTPUT->box_end();

    // Retorna o HTML gerado
    return $content;

    // --- FIM da Geração do HTML ---

    /* REMOVIDO O BLOCO QUE TENTAVA USAR RENDERER/TEMPLATE:
    // Renderiza a saída usando um template (opcional mas recomendado)
    // $output = $PAGE->get_renderer('mod_bunnyvideo'); // <<< LINHA REMOVIDA
    // ... lógica if/else removida ...
    */
}

/**
 * Saves the current playback position for a user without changing completion.
 *
 * @param int $bunnyvideoid BunnyVideo instance ID.
 * @param int $userid User ID.
 * @param float|int $position Current playback position in seconds.
 * @param float|int|null $timewatched Total watched time in seconds.
 * @return int Saved position in whole seconds.
 */
function bunnyvideo_save_playback_position($bunnyvideoid, $userid, $position, $timewatched = null)
{
    global $DB;

    $position = max(0, (int) round($position));
    $timewatched = $timewatched === null ? null : max(0, (int) round($timewatched));
    $now = time();

    $progressrecord = $DB->get_record('bunnyvideo_progress', [
        'bunnyvideoid' => $bunnyvideoid,
        'userid' => $userid,
    ]);

    if ($progressrecord) {
        $progressrecord->lastposition = $position;
        $progressrecord->positionmodified = $now;
        if ($timewatched !== null) {
            $progressrecord->timewatched = max((int) $progressrecord->timewatched, $timewatched);
        }
        $DB->update_record('bunnyvideo_progress', $progressrecord);
    } else {
        $progress = new stdClass();
        $progress->bunnyvideoid = $bunnyvideoid;
        $progress->userid = $userid;
        $progress->completionmet = 0;
        $progress->lastposition = $position;
        $progress->positionmodified = $now;
        $progress->timewatched = $timewatched === null ? 0 : $timewatched;
        $progress->timemodified = 0;
        $DB->insert_record('bunnyvideo_progress', $progress);
    }

    return $position;
}

/**
 * Função padrão do Moodle: Adiciona uma nova instância da atividade.
 * @param stdClass $bunnyvideo Objeto do formulário.
 * @param mod_bunnyvideo_mod_form $mform Definição do formulário.
 * @return int O ID da instância recém-criada.
 */
function bunnyvideo_add_instance($bunnyvideo, $mform)
{
    global $DB;

    $bunnyvideo->timecreated = time();
    $bunnyvideo->timemodified = $bunnyvideo->timecreated;

    // completionpercent agora é tratado corretamente por data_postprocessing em mod_form.php
    // Não é mais necessário verificar/desdefinir 'completionwhenpercentreached' aqui.

    $bunnyvideo->id = $DB->insert_record('bunnyvideo', $bunnyvideo);

    // Processa as configurações de conclusão salvas por standard_completion_elements
    $cmid = $bunnyvideo->coursemodule; // Passado em $bunnyvideo por moodleform_mod

    // O Moodle tratará automaticamente as configurações de conclusão padrão
    // O campo completionpercent é armazenado em nossa tabela bunnyvideo e usado pelo nosso JS

    return $bunnyvideo->id;
}

/**
 * Função padrão do Moodle: Atualiza uma instância existente.
 * @param stdClass $bunnyvideo Objeto do formulário.
 * @param mod_bunnyvideo_mod_form $mform Definição do formulário.
 * @return bool True se bem-sucedido.
 */
function bunnyvideo_update_instance($bunnyvideo, $mform)
{
    global $DB;

    $bunnyvideo->timemodified = time();
    $bunnyvideo->id = $bunnyvideo->instance; // Passado em $bunnyvideo por moodleform_mod

    // completionpercent agora é tratado corretamente por data_postprocessing em mod_form.php
    // Não é mais necessário verificar/desdefinir 'completionwhenpercentreached' aqui.

    $result = $DB->update_record('bunnyvideo', $bunnyvideo);

    // Processa as configurações de conclusão salvas por standard_completion_elements
    $cmid = $bunnyvideo->coursemodule; // Passado em $bunnyvideo por moodleform_mod

    // O Moodle tratará automaticamente as configurações de conclusão padrão
    // O campo completionpercent é armazenado em nossa tabela bunnyvideo e usado pelo nosso JS

    return $result;
}

/**
 * Função padrão do Moodle: Exclui uma instância.
 * @param int $id O ID da instância.
 * @return bool True se bem-sucedido.
 */
function bunnyvideo_delete_instance($id)
{
    global $DB;

    if (!$bunnyvideo = $DB->get_record('bunnyvideo', array('id' => $id))) {
        return false;
    }

    // Limpa os registros de progresso de conclusão
    $DB->delete_records('bunnyvideo_progress', array('bunnyvideoid' => $bunnyvideo->id));

    // Exclusão padrão - O Moodle lida com dados de conclusão relacionados etc.
    $DB->delete_records('bunnyvideo', array('id' => $bunnyvideo->id));

    return true;
}


/**
 * Define o suporte do módulo para recursos específicos.
 * @param string $feature Constante FEATURE_xx para o recurso solicitado
 * @return mixed True se o módulo suporta o recurso, null se não sabe
 */
function bunnyvideo_supports($feature)
{
    switch ($feature) {
        case FEATURE_BACKUP_MOODLE2:
            return true;
        case FEATURE_SHOW_DESCRIPTION:
            return true;
        case FEATURE_GRADE_HAS_GRADE:
            return false; // Sem notas
        case FEATURE_GROUPS:
            return false; // Sem suporte a grupos
        case FEATURE_GROUPINGS:
            return false; // Sem suporte a agrupamentos
        case FEATURE_MOD_INTRO:
            return true;  // Campo de introdução básico
        case FEATURE_COMPLETION_TRACKS_VIEWS:
            return false; // Desativado para impedir marcação automática ao visualizar
        case FEATURE_COMPLETION_HAS_RULES:
            return true;  // Temos regras de conclusão personalizadas
        case FEATURE_MODEDIT_DEFAULT_COMPLETION:
            return true; // Padrão para conclusão rastreada
        case FEATURE_COMMENT:
            return false; // Sem comentários
        case FEATURE_RATE:
            return false; // Sem avaliação
        case FEATURE_MOD_PURPOSE:
            return MOD_PURPOSE_CONTENT; // Descreve o propósito do módulo
        default:
            return null;
    }
}

/**
 * Define todas as regras de conclusão para este módulo.
 * Retorna um array com os nomes das regras de conclusão personalizadas (além de visualização/nota)
 * Esta função é necessária para o Moodle 4.x reconhecer corretamente as regras.
 *
 * @return array Array de strings definindo as regras
 */
function bunnyvideo_get_completion_rules()
{
    return ['completionpercent'];
}

/**
 * Retorna o estado de conclusão atual para este módulo.
 * IMPORTANTE: Essa função AINDA É OBRIGATÓRIA no Moodle para avaliar
 * o estado de conclusão no backend, mesmo que tenhamos a classe custom_completion
 * (a classe actvity_custom_completion é usada primariamente para a renderização da UI das regras em Moodle 4+).
 *
 * @param stdClass $course course object
 * @param stdClass $cm course-module object
 * @param int $userid User ID
 * @param int $type Type of comparison (or/and; can be used as return value if no conditions)
 * @return bool True if completed, false if not, $type if conditions not set.
 */
function bunnyvideo_get_completion_state($course, $cm, $userid, $type)
{
    global $DB;

    error_log("BUNNYVIDEO LEGACY CALLBACK GET_STATE CALLED FOR USER {$userid} TYPE {$type}");

    // Obtém a instância para ver se completionpercent está configurado
    $bunnyvideo = $DB->get_record('bunnyvideo', ['id' => $cm->instance], 'id, completionpercent', MUST_EXIST);

    // Se nâo está configurado ou é 0, a regra é considerada satisfeita
    if (empty($bunnyvideo->completionpercent) || $bunnyvideo->completionpercent <= 0) {
        return $type; // Fallback to $type if conditions not effectively set
    }

    // Verifica se o aluno tem um registro de progresso atendido na tabela
    $progress = $DB->get_record('bunnyvideo_progress', [
        'bunnyvideoid' => $bunnyvideo->id,
        'userid' => $userid,
    ]);

    if ($progress && $progress->completionmet == 1) {
        return COMPLETION_COMPLETE;
    }

    return COMPLETION_INCOMPLETE;
}

/**
 * Determine if the completion settings have changed and whether a re-evaluation is needed.
 * Returning true forces Moodle to re-check completion for everyone. For bunnyvideo,
 * the completion is driven by the AJAX calls in the background tracking progress in our custom table.
 * We do not want Moodle deleting our progress or mass re-evaluating just because
 * properties like completionpercent changed, as this can trigger false positives when
 * rules are missing in customdata.
 * 
 * @param stdClass $olddata Antigo mform data
 * @param stdClass $newdata Novo mform data
 * @return bool True if completion state should be re-evaluated
 */
function bunnyvideo_cm_completion_settings_changed($olddata, $newdata)
{
    // Apenas retorne falso. 
    // Mudar a meta de porcentagem não deve marcar todo mundo concluído ou remover os registros
    // de quem já havia concluído pela porcentagem antiga (ao menos que o professor force reset via Moodle UI).
    return false;
}

/**
 * Obtém estilos CSS para o módulo bunnyvideo
 *
 * @return array Array de arquivos CSS para incluir
 */
function bunnyvideo_get_styles()
{
    return [new moodle_url('/mod/bunnyvideo/styles.css')];
}

/**
 * Retorna informações sobre este módulo para as informações do módulo do curso.
 * Usado pelo Moodle para exibir o módulo nas listagens do curso.
 *
 * @param stdClass $coursemodule
 * @return cached_cm_info|null Informações para exibir para a instância do módulo.
 */
function bunnyvideo_get_coursemodule_info($coursemodule)
{
    global $DB;

    // Obtém informações básicas do banco de dados
    if (
        !$bunnyvideo = $DB->get_record(
            'bunnyvideo',
            ['id' => $coursemodule->instance],
            'id, name, intro, introformat'
        )
    ) {
        return null;
    }

    // Inicializa o objeto de resultado
    $info = new cached_cm_info();
    $info->name = $bunnyvideo->name;

    // Define o conteúdo se a introdução existir e showdescription estiver habilitado
    if ($coursemodule->showdescription && $bunnyvideo->intro) {
        // Converte a introdução para html
        $info->content = format_module_intro('bunnyvideo', $bunnyvideo, $coursemodule->id, false);
    }

    // IMPORTANTE: Forçar visibilidade para todos os usuários
    // Isso corrige problemas com o módulo não aparecendo para alunos
    $info->visible = true;
    $info->visibleoncoursepage = true;

    // Configurações personalizadas adicionais
    $info->customdata = [
        'visible_to_all' => true,
    ];

    return $info;
}

/**
 * Estende a navegação do curso com o módulo BunnyVideo
 *
 * @param navigation_node $parentnode
 * @param stdClass $course
 * @param context_course $context
 */
function bunnyvideo_extend_navigation_course($parentnode, $course, $context)
{
    // Esta função garante que o módulo apareça na navegação do curso
    global $DB;

    // Garante que módulos de atividade BunnyVideo apareçam para alunos
    if (has_capability('mod/bunnyvideo:view', $context)) {
        // Normalmente não precisamos fazer nada aqui, mas incluir a função
        // sinaliza para o Moodle que o módulo deve ser considerado na navegação
    }
}

/**
 * Estende a navegação com as configurações do bunnyvideo
 *
 * @param settings_navigation $settingsnav
 * @param navigation_node $videonode
 */
function bunnyvideo_extend_settings_navigation(settings_navigation $settingsnav, navigation_node $videonode)
{
    global $PAGE;

    // Nada especial para fazer aqui, esta função é principalmente um placeholder
    // para garantir integração completa com a navegação do Moodle
}

// A função bunnyvideo_extend_navigation_completion pode ser deixada vazia por enquanto
/**
 * Adiciona links de navegação
 * @param object $node O objeto do nó de navegação
 * @param string $context A string de contexto
 */
// function bunnyvideo_extend_navigation_completion($node, $context) { } // Não é estritamente necessário agora

// Adiciona outras funções lib necessárias como placeholders de backup/restauração se necessário.
// O Moodle pode frequentemente autogerar manipuladores básicos de backup/restauração se a estrutura existir.
